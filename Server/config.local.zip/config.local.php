<?php

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'samlam24_core');
define('DB_USER', 'samlam24_Maintainer');
define('DB_PASS', 'g6zr#@cecSEKNojrjRY?!orynE9Yk3JhGpcR@3!e');

define('APP_SECRET', 'super_random_secret_key_here');